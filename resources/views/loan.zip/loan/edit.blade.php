@extends('layouts.app')
@if(Auth::guard('admin')->check())
@section('title','Admin Panel')

@endif
@section('content-page')
    <div class="container">
        <div class="page-inner">
            <div class="page-header">
                <h3 class="fw-bold mb-3">Loan </h3>
                <ul class="breadcrumbs mb-3">
                    <li class="nav-home">
                        <a href="{{ route('index') }}">
                            <i class="icon-home"></i>
                        </a>
                    </li>
                    <li class="separator">
                        <i class="icon-arrow-right"></i>
                    </li>
                    <li class="nav-item">
                        <a href="{{ route('admin.owner.index')}}">Loan </a>
                    </li>
                    <li class="separator">
                        <i class="icon-arrow-right"></i>
                    </li>
                    <li class="nav-item">
                        <a href="#">Edit Loan</a>
                    </li>
                </ul>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <div class="card-title">Edit Loan </div>
                        </div>
                        <form method="POST" action="{{ route('admin.loan.update', $data->id ) }}" id="vehicleForm" >
                            @csrf
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="vehicle_no">Vehicle No<span style="color: red">*</span></label>
                                            <select name="vehicle_id" id="" class="form-control">
                                                <option value="">Select Vehicle</option>
                                                @foreach($vehicles as $vehicle)
                                                    <option {{ $data->vehicle_id == $vehicle->id ? 'selected' : '' }}
                                                     value="{{$vehicle->id }}">{{ $vehicle->vehicle_no }}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="finance_by">Financed By </label>
                                            <input type="text" class="form-control" value="{{ $data->finance_by ?? NULL }}" name="finance_by" id="finance_by" placeholder="for eg: Bank, firm, etc" />
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="loan_amount">Financed Amount </label>
                                            <input type="number" class="form-control" value="{{ $data->loan_amount ?? NULL }}" name="loan_amount" id="loan_amount" placeholder="Enter a financed amount" />
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="loan_account">Financed Account </label>
                                            <input type="text" class="form-control"  value="{{ $data->loan_account}}" name="loan_account" id="loan_account" placeholder="Enter a financed Account" />
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="emi_amount">EMI Amount </label>
                                            <input type="number" class="form-control"  value="{{ $data->emi_amount ?? NULL }}" name="emi_amount" id="emi_amount" placeholder="Enter a EMI Amount" />
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="total_emi">Total EMI </label>
                                            <input type="number" class="form-control" value="{{ $data->total_emi ?? NULL }}" name="total_emi" id="total_emi" placeholder="Enter a Total EMI " />
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="emi_paid">EMI Paid</label>
                                            <input type="number" class="form-control" value="{{ $data->emi_paid ?? NULL }}" name="emi_paid" id="emi_paid" placeholder="Enter a Total EMI " />
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="emi_paid">EMI Paid</label>
                                            <input type="number" class="form-control" value="{{ $data->emi_paid ?? NULL }}" name="emi_paid" id="emi_paid" placeholder="Enter a Total EMI " />
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="start_date">Start Date</label>
                                            <input type="date" class="form-control" value="{{ $data->start_date ?? NULL }}" name="start_date" id="start_date" placeholder="" />
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="end_date">End Date</label>
                                            <input type="date" class="form-control" value="{{ $data->end_date ?? NULL }}" name="end_date" id="end_date" placeholder="" />
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="rate_of_interest">Rate of Interst</label>
                                            <input type="number" class="form-control" value="{{ $data->rate_of_interest ?? NULL }}" name="rate_of_interest" id="rate_of_interest" placeholder="Enter Rate of Interst" />
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="rate_of_interest">Status</label>
                                            <select name="status" id="status" class="form-control">
                                                <option value="">Select status</option>
                                                <option {{$data->status == "On Going" ? 'selected': '' }} value="On Going">On Going</option>
                                                <option {{$data->status == "Completed" ? 'selected': '' }} value="Completed">Completed</option>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="installment_date">Date of Installment</label>
                                            <input type="text" class="form-control" value="{{ $installment->installment_date  }}" name="installment_date" id="installment_date" placeholder="" required/>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card-action">
                                <button class="btn btn-success" type="submit">Submit</button>
                                <a href="{{ route('admin.loan.index')}}" class="btn btn-danger" >Cancel</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('footer-script')

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.5/dist/jquery.validate.min.js"></script>

<script>
    $(document).ready(function () {
        $('#vehicle_no, #vehicle_chassis_no').on('blur', function () {
            let field = $(this).attr('name'); // Get the field name ('vehicle_no' or 'vehicle_chassis_no')
            let value = $(this).val();
            let input = $(this);

            if (value) {
                $.ajax({
                    url: "{{ route('admin.loan.checkVehicle') }}",
                    type: "POST",
                    data: {
                        _token: "{{ csrf_token() }}",
                        field: field,
                        value: value,
                    },
                    success: function (response) {
                        if (response.exists) {
                            // Display the error message
                            input.addClass('is-invalid');
                            input.next('.invalid-feedback').remove();
                            input.after(`<div class="invalid-feedback">${response.message}</div>`);
                        } else {
                            // Clear the error message if the field is valid
                            input.removeClass('is-invalid');
                            input.next('.invalid-feedback').remove();
                        }
                    },
                    error: function () {
                        alert('An error occurred while checking the field. Please try again.');
                    }
                });
            }
        });

        $('#vehicleForm').on('submit', function (e) {
            if ($('.is-invalid').length > 0) {
                e.preventDefault(); // Prevent submission if there are errors
                alert('Please fix errors before submitting the form.');
            }
        });
    });
</script>

<script>


$(document).ready(function () {
    $("#vehicleForm").validate({
        onfocusout: function (element) {
            this.element(element); // Validate the field on blur
        },
        onkeyup: false, // Disable validation on keyup for better performance
        rules: {
            vehicle_id: {
                required: true
            },
            finance_by: {
                required: true,
                maxlength: 255
            },
            loan_amount: {
                required: true,
                min: 0
            },
            loan_account: {
                required: true
            },
            emi_amount: {
                required: true,
                number: true,
                min: 0
            },
            total_emi: {
                required: true,
                digits: true,
                min: 0
            },
            emi_paid: {
                required: true,
                digits: true,
                min: 0
            },
            pending_emi: {
                required: true,
                digits: true,
                min: 0
            },
            start_date: {
                required: true,
                date: true
            },
            end_date: {
                required: true,
                date: true
            },
            rate_of_interest: {
                required: true,
                number: true,
                min: 0
            },
            installment_date: {
                required: true,
                min: 0
            },
            status: {
                required: true
            }
        },
        messages: {
            vehicle_id:{
                required: "Please select a vehicle."
            },
            finance_by: {
                required: "Please enter finance by.",
                maxlength: "Finance by cannot exceed 255 characters."
            },
            loan_amount: {
                required: "Please enter loan amount.",
                number: "Please enter a valid loan amount.",
                min: "Loan amount cannot be negative."
            },
            loan_account: {
                required: "Please enter loan account number.",
            },
            emi_amount: {
                required: "Please enter EMI amount.",
                number: "Please enter a valid EMI amount.",
                min: "EMI amount cannot be negative."
            },
            total_emi: {
                required: "Please enter total EMI to be paid.",
                digits: "Please enter a valid total EMI.",
                min: "Total EMI cannot be negative."
            },
            emi_paid: {
                required: "Please enter EMI paid.",
                digits: "Please enter a valid EMI paid.",
                min: "EMI paid cannot be negative."
            },
            pending_emi: {
                required: "Please enter pending EMI.",
                digits: "Please enter a valid Pending EMI .",
                min: "Pending EMI cannot be negative."
            },
            start_date: {
                required: "Please select start date.",
                date: "Please enter a valid start date."
            },
            end_date: {
                required: "Please select end date.",
                date: "Please enter a valid end date."
            },
            rate_of_interest: {
                required: "Please enter rate of interest.",
                number: "Please enter a valid rate of interest.",
                min: "Rate of interest cannot be negative."
            },
            installment_date: {
                required: "Please select installment date.",
              
                min: "Installment date cannot be negative."
            },
            status: {
                required: "Please select loan status."
            }
        },
        errorClass: "text-danger",
        errorElement: "span",
        highlight: function (element) {
            $(element).addClass("is-invalid");
        },
        unhighlight: function (element) {
            $(element).removeClass("is-invalid");
        },
        submitHandler: function (form) {
            // Handle successful validation here
            form.submit();
        }
    });
});


    </script>

@endsection
