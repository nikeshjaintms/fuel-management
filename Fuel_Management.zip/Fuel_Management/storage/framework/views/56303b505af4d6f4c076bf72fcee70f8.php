
      </div>

      <!-- Custom template | don't include it in your project! -->
      
        
<?php /**PATH C:\xampp\htdocs\Fuel_Management\resources\views/layouts/footer.blade.php ENDPATH**/ ?>